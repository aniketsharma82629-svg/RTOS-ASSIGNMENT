#include <Arduino_APDS9960.h>

void setup() {
  Serial.begin(9600);

  while (!Serial);

  if (!APDS.begin()) {
    Serial.println("Error initializing APDS9960!");
    while (1);
  }

  Serial.println("Gesture Detection Started");
}

void loop() {
  if (APDS.gestureAvailable()) {

    int gesture = APDS.readGesture();

    switch (gesture) {
      case GESTURE_UP:
        Serial.println("Gesture: UP");
        break;

      case GESTURE_DOWN:
        Serial.println("Gesture: DOWN");
        break;

      case GESTURE_LEFT:
        Serial.println("Gesture: LEFT");
        break;

      case GESTURE_RIGHT:
        Serial.println("Gesture: RIGHT");
        break;

      default:
        Serial.println("Unknown Gesture");
        break;
    }
  }
}