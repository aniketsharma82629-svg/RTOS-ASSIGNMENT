#include <Arduino_LSM9DS1.h>

float x, y, z;

#define RED   LEDR
#define GREEN LEDG
#define BLUE  LEDB

void setup() {
  Serial.begin(9600);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

  // Turn LEDs OFF initially (active LOW)
  digitalWrite(RED, HIGH);
  digitalWrite(GREEN, HIGH);
  digitalWrite(BLUE, HIGH);

  if (!IMU.begin()) {
    Serial.println("Failed to initialize IMU!");
    while (1);
  }

  Serial.println("IMU Tilt Control RGB LED");
}

void loop() {
  if (IMU.accelerationAvailable()) {
    IMU.readAcceleration(x, y, z);

    // Turn OFF all LEDs
    digitalWrite(RED, HIGH);
    digitalWrite(GREEN, HIGH);
    digitalWrite(BLUE, HIGH);

    if (x > 0.5) {
      // Right → Green
      digitalWrite(GREEN, LOW);
      Serial.println("Tilt Right");
    }
    else if (x < -0.5) {
      // Left → Red
      digitalWrite(RED, LOW);
      Serial.println("Tilt Left");
    }
    else if (y > 0.5) {
      // Forward → Blue
      digitalWrite(BLUE, LOW);
      Serial.println("Tilt Forward");
    }
    else {
      // Flat → White
      digitalWrite(RED, LOW);
      digitalWrite(GREEN, LOW);
      digitalWrite(BLUE, LOW);
      Serial.println("Flat");
    }

    delay(300);
  }
}