const int potPin = A6;

void setup() {
  Serial.begin(9600);
  while (!Serial);

  Serial.println("Reading Potentiometer...");
}

void loop() {
  int value = analogRead(potPin);

  Serial.print("Value: ");
  Serial.println(value);

  delay(200);
}