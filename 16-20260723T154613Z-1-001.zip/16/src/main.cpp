#include <Arduino.h>
#include <mbed.h>

mbed::Ticker timer;
volatile bool ledState = false;

// Timer Interrupt Service Routine
void timerISR() {
  ledState = !ledState;
  digitalWrite(LED_BUILTIN, ledState);
}

void setup() {
  pinMode(LED_BUILTIN, OUTPUT);

  // Trigger interrupt every 1 second
  timer.attach(&timerISR, 1.0f);
}

void loop() {
  // Nothing here
}