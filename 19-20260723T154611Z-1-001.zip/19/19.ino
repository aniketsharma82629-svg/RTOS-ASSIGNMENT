#include <ArduinoBLE.h>

#define RED   LEDR
#define GREEN LEDG
#define BLUE  LEDB

BLEService ledService("19B10000-E8F2-537E-4F6C-D104768A1214");

BLEByteCharacteristic ledCharacteristic(
  "19B10001-E8F2-537E-4F6C-D104768A1214",
  BLERead | BLEWrite
);

void setup() {
  Serial.begin(9600);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

  // Turn OFF all LEDs (active LOW)
  digitalWrite(RED, HIGH);
  digitalWrite(GREEN, HIGH);
  digitalWrite(BLUE, HIGH);

  if (!BLE.begin()) {
    Serial.println("Starting BLE failed!");
    while (1);
  }

  BLE.setLocalName("Nano33BLE");
  BLE.setAdvertisedService(ledService);

  ledService.addCharacteristic(ledCharacteristic);
  BLE.addService(ledService);

  ledCharacteristic.writeValue(0);

  BLE.advertise();

  Serial.println("BLE RGB LED Control Ready");
}

void loop() {
  BLEDevice central = BLE.central();

  if (central) {
    Serial.print("Connected: ");
    Serial.println(central.address());

    while (central.connected()) {

      if (ledCharacteristic.written()) {

        byte value = ledCharacteristic.value();

        // Turn OFF all LEDs
        digitalWrite(RED, HIGH);
        digitalWrite(GREEN, HIGH);
        digitalWrite(BLUE, HIGH);

        switch (value) {

          case 1:
            digitalWrite(RED, LOW);
            Serial.println("RED");
            break;

          case 2:
            digitalWrite(GREEN, LOW);
            Serial.println("GREEN");
            break;

          case 3:
            digitalWrite(BLUE, LOW);
            Serial.println("BLUE");
            break;

          case 4:
            digitalWrite(RED, LOW);
            digitalWrite(GREEN, LOW);
            digitalWrite(BLUE, LOW);
            Serial.println("WHITE");
            break;

          default:
            Serial.println("OFF");
        }
      }
    }

    Serial.println("Disconnected");
  }
}