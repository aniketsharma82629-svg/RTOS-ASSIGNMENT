#include <PDM.h>

#define RED   LEDR
#define GREEN LEDG
#define BLUE  LEDB

short sampleBuffer[256];
volatile int samplesRead = 0;

const int THRESHOLD = 1500;   // Adjust this value if needed

void onPDMdata() {
  int bytesAvailable = PDM.available();
  PDM.read(sampleBuffer, bytesAvailable);
  samplesRead = bytesAvailable / 2;
}

void setup() {
  Serial.begin(9600);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

  // Turn all LEDs OFF (Active LOW)
  digitalWrite(RED, HIGH);
  digitalWrite(GREEN, HIGH);
  digitalWrite(BLUE, HIGH);

  PDM.onReceive(onPDMdata);

  if (!PDM.begin(1, 16000)) {
    Serial.println("Failed to start microphone!");
    while (1);
  }

  Serial.println("Sound Threshold LED Control");
}

void loop() {

  if (samplesRead) {

    long sum = 0;

    for (int i = 0; i < samplesRead; i++) {
      sum += abs(sampleBuffer[i]);
    }

    int soundLevel = sum / samplesRead;

    Serial.print("Sound Level: ");
    Serial.println(soundLevel);

    // Turn OFF LEDs
    digitalWrite(RED, HIGH);
    digitalWrite(GREEN, HIGH);
    digitalWrite(BLUE, HIGH);

    if (soundLevel > THRESHOLD) {
      // Loud sound -> Red
      digitalWrite(RED, LOW);
    } else {
      // Quiet -> Green
      digitalWrite(GREEN, LOW);
    }

    samplesRead = 0;
    delay(100);
  }
}