#include <Arduino_APDS9960.h>

#define RED   LEDR
#define GREEN LEDG
#define BLUE  LEDB

void setup() {
  Serial.begin(9600);

  pinMode(RED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(BLUE, OUTPUT);

  // Turn all LEDs OFF (RGB LED is active LOW)
  digitalWrite(RED, HIGH);
  digitalWrite(GREEN, HIGH);
  digitalWrite(BLUE, HIGH);

  if (!APDS.begin()) {
    Serial.println("Failed to initialize APDS9960!");
    while (1);
  }

  Serial.println("Proximity-based RGB LED Control");
}

void loop() {
  if (APDS.proximityAvailable()) {

    int proximity = APDS.readProximity();   // Range: 0–255
    Serial.print("Proximity: ");
    Serial.println(proximity);

    // Turn OFF all LEDs
    digitalWrite(RED, HIGH);
    digitalWrite(GREEN, HIGH);
    digitalWrite(BLUE, HIGH);

    if (proximity > 200) {
      // Very close -> Red
      digitalWrite(RED, LOW);
    }
    else if (proximity > 100) {
      // Medium distance -> Green
      digitalWrite(GREEN, LOW);
    }
    else {
      // Far -> Blue
      digitalWrite(BLUE, LOW);
    }

    delay(100);
  }
}