void setup() {
  Serial.begin(9600);      // Initialize serial communication
  Serial.println("Hello World");
}

void loop() {
  // Nothing to repeat
}